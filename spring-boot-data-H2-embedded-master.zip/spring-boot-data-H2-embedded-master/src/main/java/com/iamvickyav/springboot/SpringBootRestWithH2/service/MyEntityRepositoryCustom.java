package com.iamvickyav.springboot.SpringBootRestWithH2.service;

import java.util.List;

import com.iamvickyav.springboot.SpringBootRestWithH2.model.Employee;

public interface MyEntityRepositoryCustom {
	List<Employee> findRecordWithQuery(String query);
}
