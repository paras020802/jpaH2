package com.iamvickyav.springboot.SpringBootRestWithH2.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;

import com.iamvickyav.springboot.SpringBootRestWithH2.model.Employee;

@Component
public class MyEntityRepositoryImpl implements MyEntityRepositoryCustom {
    @PersistenceContext
    private EntityManager em;

 

	@Override
	public List<Employee> findRecordWithQuery(String query) {
		   List<Employee> list = em.createNativeQuery(query).getResultList();
	        return list;
	}
}