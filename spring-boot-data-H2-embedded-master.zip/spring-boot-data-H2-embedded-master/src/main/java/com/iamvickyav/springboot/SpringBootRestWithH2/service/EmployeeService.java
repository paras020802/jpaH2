package com.iamvickyav.springboot.SpringBootRestWithH2.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.iamvickyav.springboot.SpringBootRestWithH2.model.Employee;

public interface EmployeeService extends JpaRepository<Employee, Integer>{

	
//	Employee findRecordWithQuery(String attribute,String table,String filter);
}
