package com.iamvickyav.springboot.SpringBootRestWithH2.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.iamvickyav.springboot.SpringBootRestWithH2.model.Parameter;

public interface ParameterService extends JpaRepository<Parameter, Integer>{
}
