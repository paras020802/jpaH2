package com.wellsfargo.eda.dds.filegeneration.controller;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.PassThroughLineAggregator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.wellsfargo.eda.dds.filegeneration.model.VEpxPriceFinalAll;
import com.wellsfargo.eda.dds.filegeneration.util.FileConstants;
import com.wellsfargo.eda.dds.filegeneration.util.FileGenerationUtil;

@RestController
@RequestMapping(value = "/rest/data/generation/mongo")
public class FileGenerationControllerMongo<metadataMap>  {
	
	private static final Logger logger = LoggerFactory.getLogger(FileGenerationControllerMongo.class);

	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${map1.table1}")
	private String appTitle;

	@Value("${config.service.host}")
	private String host;
	
	
	@Value("${config.service.port}")
	private String port;

	private final MongoTemplate mongoTemplate;

	@Autowired
	public FileGenerationControllerMongo(MongoTemplate mongoTemplate) {
		this.mongoTemplate = mongoTemplate;
	}
	
	private static Map<String, String> headerMap = new HashMap<String, String>();
	

	/**
	 * 
	 * @param user_id
	 * @return
	 * @throws SQLException
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 * @throws URISyntaxException
	 * @throws ParseException
	 */

	@GetMapping
	public ResponseEntity<String> getDataExtractor(@RequestParam String jobId) {

		try {
			String[] listvalues = appTitle.split(";");
			for (String str : listvalues) {
				String str1[] = str.split(":");
				headerMap.put(str1[0], str1[1]);
			}

			String fileUrl = null;
			fileUrl = "http://" + host + ":" + port
					+ "/configextractor/api/getFileGenerationDetails?clientName=EPX&channelType=OUTBOUND";

			Map<String, String> propMap = new LinkedHashMap<String, String>();
			ResponseEntity<String> response1 = restTemplate.getForEntity(fileUrl, String.class);
			logger.info(response1.getBody().toString());

			if (response1 != null && response1.hasBody()) {
				propMap = FileGenerationUtil.getFileGenerationfromJson(response1.getBody().toString(), propMap);
				logger.info("map" + propMap.toString());
			}

			logger.info("proper map ::" + propMap.toString());

			String gzipFilePath = propMap.get(FileConstants.FILEDROPLOCATION);
			String datFilePath = propMap.get(FileConstants.FILEDROPLOCATION);
			String trgFilePath = propMap.get(FileConstants.FILENDMLOCATION);
			String dataFileName = propMap.get(FileConstants.DATAFILENAME);
			String triggerFileName = propMap.get(FileConstants.TRIGGERFILENAME);
			String dataLoadCriteria = propMap.get(FileConstants.DATALOADCRITERIA);

			String delimiter = propMap.get(FileConstants.DELIMITER);
			String gzipFilename = propMap.get(FileConstants.GZIPFILENAME);
			String gzipFlag = propMap.get(FileConstants.GZIPFLAG);

			String columnAttributes = dataLoadCriteria.substring(7, dataLoadCriteria.indexOf("from") - 1);
			String tablenameStr = dataLoadCriteria.substring(dataLoadCriteria.indexOf("from") + 5,
					dataLoadCriteria.length());

			Query query = new Query();
			org.springframework.data.mongodb.core.query.Field field = query.fields();
			List<String> strlist = Arrays.asList(columnAttributes.split("\\s*,\\s*"));
			for (String str : strlist) {
				field = field.include(str);
			}

			// date and time

			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
			Date date = new Date();

			List<VEpxPriceFinalAll> vEpxPriceFinalAllList = new ArrayList<>();
			List<String> fileOutputStrList = new ArrayList<>();
			logger.info("starttimeread from mongo::" + new Date());
			String[] attributes = columnAttributes.split("\\,");
			String effectiveDate = null;

			if (tablenameStr.equalsIgnoreCase("dps_epxpricefinal")) {
				vEpxPriceFinalAllList = mongoTemplate.find(query, VEpxPriceFinalAll.class);
				if (vEpxPriceFinalAllList != null && vEpxPriceFinalAllList.size() > 0) {
					effectiveDate = vEpxPriceFinalAllList.get(0).getEffdate().toString();
				}

				logger.info("endtimeread from mongo::" + new Date());
				fileOutputStrList = FileGenerationUtil.parseList(vEpxPriceFinalAllList, attributes, columnAttributes,
						delimiter, headerMap);
			}

			SimpleDateFormat parser = new SimpleDateFormat("EEE MMM d HH:mm:ss zzz yyyy");
			Date effdate = parser.parse(effectiveDate);
			SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
			String formattedDate = formatter.format(effdate);
			String datetime = dateFormat.format(date);
			String datetime1[] = datetime.split("\\s");
			String datafileName1[] = dataFileName.split("\\.");
			String triggerfileName1[] = triggerFileName.split("\\.");
			datafileName1[0] = datafileName1[0].replace("${AS_OF_DATE}", formattedDate).replace("${TIMESTAMP}",
					datetime1[0] + "_" + datetime1[1].replace(":", ""));
			dataFileName = datafileName1[0] + "." + datafileName1[1];
			triggerfileName1[0] = triggerfileName1[0].replace("${AS_OF_DATE}", formattedDate).replace("${TIMESTAMP}",
					datetime1[0] + "_" + datetime1[1].replace(":", ""));
			triggerFileName = triggerfileName1[0] + "." + triggerfileName1[1];
			String dataFilePath = datFilePath + dataFileName;
			String triggerFilePath = trgFilePath + triggerFileName;
			logger.info("before saving starttime::" + new Date());
			logger.info("total records:" + fileOutputStrList.size());
			FlatFileItemWriter<String> itemFileWriter = new FlatFileItemWriter<String>();

			itemFileWriter.setResource(new FileSystemResource(new File(dataFilePath)));

			itemFileWriter.setLineAggregator(new PassThroughLineAggregator<String>());
			itemFileWriter.open(new ExecutionContext());
			itemFileWriter.write(fileOutputStrList);

			FileGenerationUtil.saveTriggerFile(formattedDate, triggerFilePath, dataFileName, fileOutputStrList.size());
			logger.info("after saving file endtime::" + new Date());
			if (gzipFlag.equalsIgnoreCase("1")) {
				FileGenerationUtil.gzip(gzipFilePath, new File(gzipFilePath), gzipFilename);
			}
		} catch (Exception e) {
			logger.error("exception occured:" + e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);

		}

		logger.info("file is saved");
		return new ResponseEntity<>("data is saved", HttpStatus.OK);

	}
	


}
