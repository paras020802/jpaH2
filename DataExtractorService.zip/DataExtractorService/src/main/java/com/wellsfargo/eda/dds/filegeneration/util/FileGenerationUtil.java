package com.wellsfargo.eda.dds.filegeneration.util;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPOutputStream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wellsfargo.eda.dds.filegeneration.model.FileGenerationDetails;


/**
 * 
 * @author U761425
 *
 */

public class FileGenerationUtil {

	private static final Logger logger = LogManager.getLogger(FileGenerationUtil.class);

	/**
	 * 
	 * @param list
	 * @param filename
	 * @param records
	 */
	public static void saveTriggerFile(String effdate, String triggerFilePath , String fileName, int records) {
	
		
		String triggerfileHeader = FileConstants.EFFECTIVEDATE +"|" + FileConstants.RECORDCOUNT +"|"+ FileConstants.DATAFILENAME;
		String triggerfileData= effdate + "|"+records + "|" + fileName;
		
		String triggerData= triggerfileHeader + "\n"+triggerfileData;
		
		Path triggerFilePath1 = Paths.get(triggerFilePath);
		byte triggerdatabyte[] = triggerData.getBytes();

		try (OutputStream out1 = new BufferedOutputStream(Files.newOutputStream(triggerFilePath1))) {
			out1.write(triggerdatabyte);
		} catch (IOException x) {
			logger.error(x);
		}
	}
	
	
	/**
	 * 
	 * @param obj
	 * @param variableName
	 * @return
	 */
	

	
	public static String invokeGetter(Object obj, String variableName)
	{
		try {
			PropertyDescriptor pd = new PropertyDescriptor(variableName, obj.getClass());
			Method getter = pd.getReadMethod();
			Object f = getter.invoke(obj);
			String value = String.valueOf(f);
			return value;
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | IntrospectionException e) {
			logger.error("Exception occured"+e);
		}
		return null;
	}
	
	/**
	 * 
	 * @param list1
	 * @param attrbutes
	 * @param columnHeader
	 * @param delimiter
	 * @param map1
	 * @return
	 */
	public static List<String> parseList(List<?> list1,String[] attrbutes,String columnHeader,String delimiter,Map<String,String> map1) 
    {
     
 columnHeader =columnHeader.toLowerCase().replace(",", delimiter);
	 List<String> list = new ArrayList<>();
	 list.add(columnHeader);
	 for(int i =0;i<list1.size();i++) {
		 Object jsonobj =list1.get(i);
			 String attbuteStr="";
			 for(String attribute:attrbutes) {
				 String attributeValue = String.valueOf(invokeGetter(jsonobj,map1.get(attribute)));
				 attbuteStr=attbuteStr+attributeValue+delimiter ;
			 }
			 list.add(attbuteStr.substring(0,attbuteStr.length()-1));
			
     }
     
      
       return  list;
    }
	
	
	/**
	 * 
	 * @param response
	 * @param propMap
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public static Map<String, String> getFileGenerationfromJson(String response, Map<String, String> propMap) throws JsonParseException, JsonMappingException, IOException{
		ObjectMapper mapper = new ObjectMapper();
		List<FileGenerationDetails> fileGenerationList = Arrays.asList(mapper.readValue(response, FileGenerationDetails[].class));
		
		for(FileGenerationDetails filegeneration:fileGenerationList) {
			propMap.put(FileConstants.DATAFILENAME, filegeneration.getDataFileNm());
			propMap.put(FileConstants.DATALOADCRITERIA, filegeneration.getDataLoadCriteria());
			propMap.put(FileConstants.DELIMITER, filegeneration.getDelimiter());
			propMap.put(FileConstants.TRIGGERFILENAME, filegeneration.getTrgFileNm());
			propMap.put(FileConstants.FILEFORMAT, filegeneration.getFileFormat());
			propMap.put(FileConstants.GZIPFILENAME, filegeneration.getGzipFilenm());
			propMap.put(FileConstants.GZIPFLAG, filegeneration.getGzipFlag());
			propMap.put(FileConstants.CLIENTNAME, filegeneration.getClientName());
			propMap.put(FileConstants.FILEDROPLOCATION, filegeneration.getFileDropLocation());
			propMap.put(FileConstants.FILENDMLOCATION, filegeneration.getFileNdmLocation());
			
	
		}
		return propMap;
	}
	
	
	/**
	 * 
	 * @param zipPath
	 * @param folder
	 * @param gzipFilename
	 * @return
	 * @throws IOException
	 */
	public static File gzip(String zipPath,File folder , String gzipFilename) throws IOException {
		String zipFile = zipPath+gzipFilename;
		final File gzipFile = new File(zipFile);
		final byte[] buffer = new byte[1024];

		for (final File fileEntry : folder.listFiles()) {
			try (FileInputStream in = new FileInputStream(fileEntry);
					GZIPOutputStream out = new GZIPOutputStream(new FileOutputStream(gzipFile,true))) {

				int len;
				while ((len = in.read(buffer)) > 0) {
					out.write(buffer, 0, len);
				}
			}
		}

		return gzipFile;
	}
	
	

}
