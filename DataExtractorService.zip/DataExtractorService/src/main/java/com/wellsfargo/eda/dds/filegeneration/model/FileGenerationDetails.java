package com.wellsfargo.eda.dds.filegeneration.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dds_file_config")
public class FileGenerationDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer clientId;
	private String fileDropLocation;
	private String fileNdmLocation;
	
	private Integer xrefId;
	private String clientChannelType;
	private String clientName;
	private Integer channelId;
	private String channelName;
	private String dataFileNm;
	private String trgFileNm;
	private String dataLoadCriteria;
	private String fileFormat;
	private String delimiter;
	private String gzipFlag;
	private String gzipFilenm;


	public FileGenerationDetails() {
	}


	public String getClientName() {
		return clientName;
	}


	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public Integer getXrefId() {
		return xrefId;
	}


	public void setXrefId(Integer xrefId) {
		this.xrefId = xrefId;
	}


	public String getClientChannelType() {
		return clientChannelType;
	}
	
	public Integer getClientId() {
		return clientId;
	}


	public void setClientId(Integer clientId) {
		this.clientId = clientId;
	}
	


	public String getFileDropLocation() {
		return fileDropLocation;
	}


	public void setFileDropLocation(String fileDropLocation) {
		this.fileDropLocation = fileDropLocation;
	}


	public String getFileNdmLocation() {
		return fileNdmLocation;
	}


	public void setFileNdmLocation(String fileNdmLocation) {
		this.fileNdmLocation = fileNdmLocation;
	}


	public void setClientChannelType(String clientChannelType) {
		this.clientChannelType = clientChannelType;
	}


	public Integer getChannelId() {
		return channelId;
	}


	public void setChannelId(Integer channelId) {
		this.channelId = channelId;
	}


	public String getChannelName() {
		return channelName;
	}


	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}


	public String getDataFileNm() {
		return dataFileNm;
	}

	public void setDataFileNm(String dataFileNm) {
		this.dataFileNm = dataFileNm;
	}

	public String getTrgFileNm() {
		return trgFileNm;
	}

	public void setTrgFileNm(String trgFileNm) {
		this.trgFileNm = trgFileNm;
	}


	public String getDataLoadCriteria() {
		return dataLoadCriteria;
	}

	public void setDataLoadCriteria(String dataLoadCriteria) {
		this.dataLoadCriteria = dataLoadCriteria;
	}

	public String getFileFormat() {
		return fileFormat;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public String getGzipFlag() {
		return gzipFlag;
	}

	public void setGzipFlag(String gzipFlag) {
		this.gzipFlag = gzipFlag;
	}

	public String getGzipFilenm() {
		return gzipFilenm;
	}

	public void setGzipFilenm(String gzipFilenm) {
		this.gzipFilenm = gzipFilenm;
	}

	@Override
	public String toString() {
		return "Source{" + "xrefId=" + xrefId + ", clientName=" + clientName + ", dataFileNm='" + dataFileNm + '\'' + ", trgFileNm='" + trgFileNm
				+ '\'' + ", dataLoadCriteria='" + dataLoadCriteria + "fileFormat=" + fileFormat + ", delimiter=" + delimiter 
		+ '\'' + ", gzipFlag='" + gzipFlag + " gzipFilenm=" + gzipFilenm + " clientId=" + clientId + " fileDropLocation=" + fileDropLocation + " fileNdmLocation=" + fileNdmLocation + '}';
	}
}
