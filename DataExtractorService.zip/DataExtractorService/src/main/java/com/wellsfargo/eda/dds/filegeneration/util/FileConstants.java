package com.wellsfargo.eda.dds.filegeneration.util;

public class FileConstants {
	
	public static final String DATAFILENAME = "dataFileName";
	public static final String DATALOADCRITERIA = "dataLoadCriteria";
	public static final String DELIMITER = "delimiter";
	public static final String TRIGGERFILENAME = "triggerFileName";
	public static final String FILEFORMAT = "fileFormat";
	public static final String GZIPFILENAME = "gzipFileName";
	public static final String GZIPFLAG = "gzipFlag";
	public static final String CLIENTNAME = "clientName";
	public static final String RECORDCOUNT = "record_count";
	public static final String EFFECTIVEDATE = "effective_date";
	public static final String FILEDROPLOCATION = "fileDropLocation";
	public static final String FILENDMLOCATION = "fileNdmLocation";
	
	

}



