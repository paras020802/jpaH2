package com.wellsfargo.eda.dds.filegeneration.model;



import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.sql.Clob;
import java.util.Date;
import java.util.Objects;


@Document(collection = "dps_epxpricefinal")
public class VEpxPriceFinalAll {
	
 @org.springframework.data.annotation.Id	
 private String id;	

  @Field("RAWDATAJSON")
  private Clob rawDataJson;
  @Field("LASTUPDATETIME")
  private Date lastUpdateTime;
  @Field("AUDITLOG")
  private String auditLog;
  @Field("CURRENCY")
  private String  currency;
  @Field("ISMARKETPRICE")
  private String  isMarketPrice;
  @Field("ISFINALPRICE")
  private String  isFinalPrice;
  @Field("BR_SYSTEM")
  private String brSystem;
  @Field("EFFDATE")
  private Date  effdate;
  @Field("PX_SRC")
  private String  pxSrc;
  @Field("ACT_TREATMENT")
  private String  actTreatment;
  @Field("PRICE")
  private Number  price;
  @Field("SUB_TYPE")
  private String  subType;
  @Field("SUP_TYPE")
  private String  supType;
  @Field("PRODUCTID")
  private Number  productId;
  @Field("BR_ID")
  private String  brId;
  @Field("COMMON")
  private String  common;
  @Field("SEDOL")
  private String  sedol;
  @Field("ISIN")
  private String  isin;
  @Field("CUSIP")
  private String  cusip;
  @Field("IDENTIFIER")
  private String  identifier;
public Clob getRawDataJson() {
	return rawDataJson;
}
public void setRawDataJson(Clob rawDataJson) {
	this.rawDataJson = rawDataJson;
}
public Date getLastUpdateTime() {
	return lastUpdateTime;
}
public void setLastUpdateTime(Date lastUpdateTime) {
	this.lastUpdateTime = lastUpdateTime;
}
public String getAuditLog() {
	return auditLog;
}
public void setAuditLog(String auditLog) {
	this.auditLog = auditLog;
}
public String getCurrency() {
	return currency;
}
public void setCurrency(String currency) {
	this.currency = currency;
}
public String getIsMarketPrice() {
	return isMarketPrice;
}
public void setIsMarketPrice(String isMarketPrice) {
	this.isMarketPrice = isMarketPrice;
}
public String getIsFinalPrice() {
	return isFinalPrice;
}
public void setIsFinalPrice(String isFinalPrice) {
	this.isFinalPrice = isFinalPrice;
}
public String getBrSystem() {
	return brSystem;
}
public void setBrSystem(String brSystem) {
	this.brSystem = brSystem;
}
public Date getEffdate() {
	return effdate;
}
public void setEffdate(Date effdate) {
	this.effdate = effdate;
}
public String getPxSrc() {
	return pxSrc;
}
public void setPxSrc(String pxSrc) {
	this.pxSrc = pxSrc;
}
public String getActTreatment() {
	return actTreatment;
}
public void setActTreatment(String actTreatment) {
	this.actTreatment = actTreatment;
}
public Number getPrice() {
	return price;
}
public void setPrice(Number price) {
	this.price = price;
}
public String getSubType() {
	return subType;
}
public void setSubType(String subType) {
	this.subType = subType;
}
public String getSupType() {
	return supType;
}
public void setSupType(String supType) {
	this.supType = supType;
}
public Number getProductId() {
	return productId;
}
public void setProductId(Number productId) {
	this.productId = productId;
}
public String getBrId() {
	return brId;
}
public void setBrId(String brId) {
	this.brId = brId;
}
public String getCommon() {
	return common;
}
public void setCommon(String common) {
	this.common = common;
}
public String getSedol() {
	return sedol;
}
public void setSedol(String sedol) {
	this.sedol = sedol;
}
public String getIsin() {
	return isin;
}
public void setIsin(String isin) {
	this.isin = isin;
}
public String getCusip() {
	return cusip;
}
public void setCusip(String cusip) {
	this.cusip = cusip;
}
public String getIdentifier() {
	return identifier;
}
public void setIdentifier(String identifier) {
	this.identifier = identifier;
}
  
  
  

  @Override
  public String toString() {
    return "VEpxPriceFinalAll{" +
      "rawDataJson='" + rawDataJson + '\'' +
      ",lastUpdateTime=" + lastUpdateTime +
      ", auditLog='" + auditLog + '\'' +
      ", currency='" + currency + '\'' +
      ", isMarketPrice='" + isMarketPrice + '\'' +
      ", isFinalPrice='" + isFinalPrice + '\'' +
      ", brSystem=" + brSystem +
      ", effdate=" + effdate +
      ", pxSrc='" + pxSrc + '\'' +
      ", actTreatment='" + actTreatment + '\'' +
      ", price='" + price + '\'' +
      ", subType='" + subType + '\'' +
      ", supType='" + supType + '\'' +
      ", productId='" + productId + '\'' +
      ", brId='" + brId + '\'' +
      ", common='" + common + '\'' +
      ", sedol='" + sedol + '\'' +
      ", isin='" + isin + '\'' +
      ", cusip='" + cusip + '\'' +
      ", identifier='" + identifier + '\'' +
      
      '}';
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    VEpxPriceFinalAll vepxPrice = (VEpxPriceFinalAll) o;
    return Objects.equals(rawDataJson, vepxPrice.rawDataJson) &&
      Objects.equals(lastUpdateTime, vepxPrice.lastUpdateTime) &&
      Objects.equals(auditLog, vepxPrice.auditLog) &&
      Objects.equals(currency, vepxPrice.currency) &&
      Objects.equals(isMarketPrice, vepxPrice.isMarketPrice) &&
      Objects.equals(isFinalPrice, vepxPrice.isFinalPrice) &&
      Objects.equals(brSystem, vepxPrice.brSystem) &&
      Objects.equals(effdate, vepxPrice.effdate) &&
      Objects.equals(pxSrc, vepxPrice.pxSrc) &&
      Objects.equals(actTreatment, vepxPrice.actTreatment) &&
      Objects.equals(price, vepxPrice.price) &&
      Objects.equals(subType, vepxPrice.subType) &&
      Objects.equals(supType, vepxPrice.supType) &&
      Objects.equals(productId, vepxPrice.productId) &&
      Objects.equals(brId, vepxPrice.brId) &&
      Objects.equals(common, vepxPrice.common) &&
      Objects.equals(sedol, vepxPrice.sedol) &&
      Objects.equals(isin, vepxPrice.isin) &&
      Objects.equals(cusip, vepxPrice.cusip) &&
      Objects.equals(identifier, vepxPrice.identifier);
  }

  @Override
  public int hashCode() {
    return Objects.hash(rawDataJson, lastUpdateTime, auditLog, currency, isMarketPrice, isFinalPrice, brSystem, effdate, pxSrc, actTreatment, price,subType,supType,productId,brId,common,sedol,isin, cusip,identifier);
  }
}