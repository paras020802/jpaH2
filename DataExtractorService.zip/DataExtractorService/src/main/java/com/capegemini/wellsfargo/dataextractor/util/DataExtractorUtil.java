package com.capegemini.wellsfargo.dataextractor.util;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.capegemini.wellsfargo.dataextractor.model.Metadata;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DataExtractorUtil {
	
	public static String getTableNameFromQuery(String query) {
		String tableName = null;
		if (query.contains("where")) {
			tableName = query.substring(query.indexOf("from") + 4, query.indexOf("where") - 1).trim();
		} else {
			tableName = query.substring(query.indexOf("from") + 4, query.length()).trim();
		}
		return tableName;

	}

	public static List<String> getColumnHeaderList(String header) {
		
		String[] headerArr = header.split("\\,");
		List<String> headerList = Arrays.asList(headerArr);
		headerList.replaceAll(String::trim);
		return headerList;
	}
	
	
	public static String getColumnHeaderString(String query) {
		String header = query.substring(6, query.indexOf("from") - 1);
		System.out.println("newheader::" + header.trim());
		return header;
	}
	
	public static Map<String,String> getMetadataMapfromJson(String response) throws JsonParseException, JsonMappingException, IOException{
		Map<String, String> metadataMap = new LinkedHashMap<String, String>();
		ObjectMapper mapper = new ObjectMapper();
		List<Metadata> metadataList = Arrays.asList(mapper.readValue(response, Metadata[].class));
		
		for(Metadata metadata:metadataList) {
			metadataMap.put(metadata.getColumnName(),metadata.getColumnType());
		}
		return metadataMap;

	}
	public static void saveDataToFile(List<?> list, String filename) {
		String str1 = "";
		for (int i = 0; i < list.size(); i++) {
			str1 = str1 + list.get(i).toString() + "\n";

		}
		System.out.println(str1);
		byte data[] = str1.getBytes();
		Path p = Paths.get("C://work/" + filename + ".txt");

		try (OutputStream out = new BufferedOutputStream(Files.newOutputStream(p))) {
			out.write(data, 0, data.length);
		} catch (IOException x) {
			System.err.println(x);
		}
	}
}
