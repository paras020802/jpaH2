package com.capegemini.wellsfargo.dataextractor.repository;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import org.hibernate.exception.SQLGrammarException;
import org.springframework.stereotype.Component;

@Component
public class DataExtractorRepositoryImpl implements DataExtractorRepository {

	@PersistenceContext
    private EntityManager em;

 

	@Override
	public <T> List<T> findRecordWithQuery(String query) throws PersistenceException {
		List list = new ArrayList();
		try {
			list = em.createNativeQuery(query).getResultList();
	        
		}catch(PersistenceException e) {
			
			SQLException sqe = new SQLException(e.getCause());
			
			throw new SQLGrammarException("sql grammer exception", sqe, query);
		}
		return list;
	}
}
