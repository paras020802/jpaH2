package com.capegemini.wellsfargo.dataextractor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class DataExtractorClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataExtractorClientApplication.class, args);
	}
}

@Configuration
class config{
	
	
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
}
