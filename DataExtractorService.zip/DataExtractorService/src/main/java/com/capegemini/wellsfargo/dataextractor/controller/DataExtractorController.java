package com.capegemini.wellsfargo.dataextractor.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.capegemini.wellsfargo.dataextractor.service.DataExtractorService;
import com.capegemini.wellsfargo.dataextractor.util.DataExtractorUtil;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@RestController
@RequestMapping(value = "/rest/data/extractor")
public class DataExtractorController<metadataMap> {

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private DataExtractorService dataExtractorService;

	@GetMapping
	public ResponseEntity<String> getDataExtractor(@RequestParam String query)
			throws SQLException, JsonParseException, JsonMappingException, IOException {

		

		String tableName = DataExtractorUtil.getTableNameFromQuery(query);
		String header = DataExtractorUtil.getColumnHeaderString(query);
		List<String> headerList = DataExtractorUtil.getColumnHeaderList(header);
		String url = null;
		if (query.contains("*")) {
			url = "http://localhost:8071/rest/metadata/service?table=" + tableName;
		} else {
			url = "http://localhost:8071/rest/metadata/service?header=" + header + "&table=" + tableName;
		}

		ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
		System.out.println(response.getBody().toString());

		// {last_name=VARCHAR, first_name=VARCHAR,}
		Map<String, String> metadataMap = new LinkedHashMap<String, String>();
		if (response != null && response.hasBody()) {
			metadataMap = DataExtractorUtil.getMetadataMapfromJson(response.getBody().toString());
			String columnNotFound="";
			for(String column:headerList) {
				if(!metadataMap.containsKey(column.toUpperCase())) {
					columnNotFound=columnNotFound+column+",";
				}
			}
			if(columnNotFound.trim().isEmpty()) {
				columnNotFound = columnNotFound.substring(0,columnNotFound.lastIndexOf(",")-1);
				return ResponseEntity.ok().body("columns name are not matching in DB::"+columnNotFound);
			}
		}

		System.out.println("response::" + response);
		System.out.println("query::" + query);
		
		List<Object> list = new ArrayList<>();
		try {
			list = dataExtractorService.getDataExtractor(query);
		} catch (SQLException e) {
				return ResponseEntity.ok().body("Invalid query for syntax error in query");
		}

		if (list != null && list.size() > 0) {
			JSONArray jsonArray = dataExtractorService.getDataExtractorResult(list, metadataMap, query);
			return ResponseEntity.ok().body(jsonArray.toString());
		} else {
			return ResponseEntity.ok().body("No result is found for this query");
		}

	}

}
