package com.wf.ede.dds.exception;

public class DdsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DdsException(String message, Throwable cause) {
		super(message, cause);

	}

	public DdsException(String message) {
		super(message);
	}

}
