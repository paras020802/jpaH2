package com.wf.ede.dds.exception;

public class ConfigDataUnavailableException extends DdsException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ConfigDataUnavailableException(String message) {
		super(message);
	}

	public ConfigDataUnavailableException(String message, Throwable cause) {
		super(message, cause);
	}
	

}
