package com.capegemini.wellsfargo.metadataextractor.service.impl;

import java.util.List;

public interface MetadataService {

	List<Object> extractTablesMetadata(String query);

}
