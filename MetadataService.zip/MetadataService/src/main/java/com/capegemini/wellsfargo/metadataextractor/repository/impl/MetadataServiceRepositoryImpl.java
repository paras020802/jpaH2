package com.capegemini.wellsfargo.metadataextractor.repository.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;

import com.capegemini.wellsfargo.metadataextractor.repository.MetadataServiceRepository;

@Component
public class MetadataServiceRepositoryImpl implements MetadataServiceRepository {
    @PersistenceContext
    private EntityManager em;

 

	@Override
	public <T> List<T> findRecordWithQuery(String query) {
		   List list = em.createNativeQuery(query).getResultList();
	        return list;
	}
}