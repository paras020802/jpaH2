package com.capegemini.wellsfargo.metadataextractor.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capegemini.wellsfargo.metadataextractor.service.impl.MetadataService;

@RestController
@RequestMapping(value = "/rest/metadata")
public class MetadataServiceController {

	@Autowired
	MetadataService metadataService;

	@RequestMapping(value = "/service", method = RequestMethod.GET)
	private ResponseEntity<String> getMetaData(@RequestParam(required = false) String header,
			@RequestParam String table, @RequestParam(required = false) String param) {

		JSONArray jsonarray = new JSONArray();
		System.out.println("header::" + header);
		System.out.println("table::" + table);
		System.out.println("param::" + param);
		List<String> headerList = new ArrayList<String>();
		if (header != null) {
			String[] headerArr = header.split("\\,");
			headerList = Arrays.asList(headerArr);
			headerList.replaceAll(String::trim);
			headerList = headerList.stream().map(s -> s.toUpperCase()).collect(Collectors.toList());
		}

		String query = "select column_name,column_type from columns where table_name='" + table + "'";
		System.out.println("query::" + query);

		List<Object> list = new ArrayList<>();
		list = metadataService.extractTablesMetadata(query);

		try {
			for (int k = 0; k < list.size(); k++) {
				Object obj = list.get(k);
				JSONObject jo = new JSONObject();
				if (obj instanceof String) {
					System.out.println("object::" + obj);
					Object tuple = (Object) obj;
					String datatype = (String) list.get(0);
				} else {
					Object[] tuple = (Object[]) obj;
                    String column_name= tuple[0].toString().toUpperCase();
                    String datatype = tuple[1].toString();
					String column_type = datatype.substring(0, datatype.indexOf("(")).toUpperCase();
					String column_size = datatype.substring(datatype.indexOf("(")+1, datatype.indexOf(")"));
				if(headerList!=null && headerList.size()>0) {
					if (headerList.contains(column_name)) {
						jo.put("Column_Name", column_name);
						jo.put("column_type", column_type);
						jo.put("column_size", column_size);
						jsonarray.add(jo);
					}
				}else {
						jo.put("Column_Name", column_name);
						jo.put("column_type", column_type);
						jo.put("column_size", column_size);
						jsonarray.add(jo);
					}

				}
				
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		if (param != null) {
			// return ResponseEntity.ok().body(mapColumnNameType.toString()); // return
			// mapColumnNameType.toString();
		} else {
			return ResponseEntity.ok().body(jsonarray.toString()); // return
			// jsonarray.toString();
		}
		return ResponseEntity.ok().body(jsonarray.toString());

	}

}
