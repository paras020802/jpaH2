package com.capegemini.wellsfargo.metadataextractor.repository;

import java.util.List;

public interface MetadataServiceRepository {
	  <T> List<T> findRecordWithQuery(String query);
	 
	 
}
