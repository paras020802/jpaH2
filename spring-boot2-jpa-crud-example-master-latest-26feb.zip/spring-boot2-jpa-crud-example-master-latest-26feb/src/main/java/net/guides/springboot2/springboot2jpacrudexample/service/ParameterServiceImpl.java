package net.guides.springboot2.springboot2jpacrudexample.service;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.Ignition;
import org.springframework.stereotype.Component;

import net.guides.springboot2.springboot2jpacrudexample.model.Employee;
import net.guides.springboot2.springboot2jpacrudexample.model.Parameter;

@Component
public class ParameterServiceImpl implements ParameterService {

	public void saveParameterIgniteRepository(Parameter parameter) {
		
	try {
		Ignition.setClientMode(true);
		Ignite ignite = Ignition.start("examples/config/example-ignite.xml");
		

        // get or create cache
        IgniteCache<Integer, Parameter> cache =  ignite.getOrCreateCache("parameterCache");
        
      

        cache.put(1, parameter);
       

        System.out.println("Enter crtl-x to quite the application!!!");
	}catch(Exception e) {
		e.printStackTrace();
	}
		
	}

	

}
