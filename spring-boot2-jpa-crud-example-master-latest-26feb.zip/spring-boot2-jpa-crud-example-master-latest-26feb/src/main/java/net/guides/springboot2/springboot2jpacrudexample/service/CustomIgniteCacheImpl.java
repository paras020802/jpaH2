package net.guides.springboot2.springboot2jpacrudexample.service;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.apache.ignite.IgniteCache;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.query.QueryCursor;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import net.guides.springboot2.springboot2jpacrudexample.IgniteCacheConfiguration;



@Component
public class CustomIgniteCacheImpl implements CustomIgniteCache {
	@Autowired
	IgniteCacheConfiguration IgniteCacheConfiguration;

	@Override
	public void getDataFromIgniteCache(String query,String cacheName) {
		Ignition.setClientMode(true);
        //try (Ignite ignite = Ignition.start("C:\\work\\apache-ignite-fabric-2.6.0-bin\\examples\\config\\persistentstore\\example-persistent-store.xml")) {
			try (IgniteCache<Long, Long> cache = Ignition.start(IgniteCacheConfiguration.igniteConfiguration()).getOrCreateCache(cacheName)) {
				// Load cache with data from the database.
				cache.loadCache(null);
				// Execute query on cache.
				QueryCursor<List<?>> cursor = cache.query(new SqlFieldsQuery(query));
				List<List<?>> list = cursor.getAll();
				String str1="";
				for (int i = 0; i < list.size(); i++) {
					String str = list.get(i).toString().replaceAll(",", "|");
					
					str1 =str1+ str.substring(1, str.length() - 1) + "\n";
					
					
				}
				System.out.println(str1);
					byte data[] = str1.getBytes();
					Path p = Paths.get("C://work/"+cacheName+".txt");

					try (OutputStream out = new BufferedOutputStream(Files.newOutputStream(p))) {
						out.write(data, 0, data.length);
					} catch (IOException x) {
						System.err.println(x);
					}
				
				

			}
		}
        
        
		
	//}

}
