package net.guides.springboot2.springboot2jpacrudexample.service;

import net.guides.springboot2.springboot2jpacrudexample.model.Parameter;

public interface ParameterService {
	public void saveParameterIgniteRepository(Parameter parameter);
}
