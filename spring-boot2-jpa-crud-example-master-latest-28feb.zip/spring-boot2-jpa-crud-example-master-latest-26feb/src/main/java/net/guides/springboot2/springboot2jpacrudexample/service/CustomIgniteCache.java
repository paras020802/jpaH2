package net.guides.springboot2.springboot2jpacrudexample.service;

public interface CustomIgniteCache {
	public void getDataFromIgniteCache(String query,String cacheName) ;
}
