package net.guides.springboot2.springboot2jpacrudexample.controller;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import net.guides.springboot2.springboot2jpacrudexample.exception.ResourceNotFoundException;
import net.guides.springboot2.springboot2jpacrudexample.model.Employee;
import net.guides.springboot2.springboot2jpacrudexample.repository.EmployeeRepository;
import net.guides.springboot2.springboot2jpacrudexample.service.MyEntityRepositoryCustom;
import net.guides.springboot2.springboot2jpacrudexample.service.ParameterRepository;
import net.guides.springboot2.springboot2jpacrudexample.service.ParameterService;

@RestController
@RequestMapping("/api/v1")
public class EmployeeController {

	@Value("${spring.datasource.url}")
	private String url;

	@Value("${spring.datasource.username}")
	private String username;

	@Value("${spring.datasource.password}")
	private String password;

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private ParameterRepository parameterRepository;

	@Autowired
	private ParameterService parameterService;
	// @Autowired
	// private CustomIgniteCache customIgniteCache;
	@Autowired
	private MyEntityRepositoryCustom myEntityRepositoryCustom;

	@GetMapping("/employees")
	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();
	}

	@GetMapping("/employees/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable(value = "id") Long employeeId)
			throws ResourceNotFoundException {
		Employee employee = employeeRepository.findById(employeeId)
				.orElseThrow(() -> new ResourceNotFoundException("parameter not found for this id :: " + employeeId));
		return ResponseEntity.ok().body(employee);
	}

	@PostMapping("/employees")
	public Employee createEmployee(@Valid @RequestBody Employee employee) {
		return employeeRepository.save(employee);
	}

	@RequestMapping(value = "/table/filter", method = RequestMethod.GET)
	List<String> getEmployeewithQuery(@RequestParam String query)
			throws ResourceNotFoundException, ClassNotFoundException {
		// List<String> getEmployeewithQuery(@RequestParam Map<String,String> params)
		// throws ResourceNotFoundException, ClassNotFoundException{
		// Parameter parameter = getParameter(table);
		/*
		 * String tableName = params.get("table"); String
		 * query="select id,first_name,last_name,email_address from "
		 * +tableName+" where "; params.remove("table"); for(Map.Entry<String,String>
		 * entry: params.entrySet()) {
		 * query=query+entry.getKey()+"='"+entry.getValue()+"' and "; }
		 */

		// query= query.substring(0,query.lastIndexOf("and")-1);
		// List<?> llist = myEntityRepositoryCustom.findRecordWithQuery(query);
		String tableName = null;
		if (query.contains("where")) {
			tableName = query.substring(query.indexOf("from") + 4, query.indexOf("where") - 1).trim();
		} else {
			tableName = query.substring(query.indexOf("from") + 4, query.length()).trim();
		}

		String header = query.substring(6, query.indexOf("from") - 1);
		String newheader = header.replace(",", "|");
		System.out.println("newheader::" + newheader);

		// String filter = parameter.getFilter();
		// String filterCondtion= filter+"='"+param+"'";

		/*
		 * //String query =
		 * "select "+parameter.getAttribute()+" from "+parameter.getTable()+" where "
		 * +parameter.getFilter(); if(parameter.getFilter().equals("null")) { query =
		 * "select "+parameter.getAttribute()+" from "+parameter.getTable();
		 * 
		 * }else { query =
		 * "select "+parameter.getAttribute()+" from "+parameter.getTable()+" where "
		 * +filterCondtion;
		 * 
		 * }
		 */

		System.out.println("query::" + query);

		// customIgniteCache.getDataFromIgniteCache(query, tableName+"Cache");

		List<Object> list = new ArrayList<>();
		list = myEntityRepositoryCustom.findRecordWithQuery(query);

		List<String> liststr = new ArrayList<String>(list.size());

		try {
			Map<String, String> metadataMap = getMetaData(newheader, tableName);

			// if(tableName.equalsIgnoreCase("Employee")) {

			Iterator<Object> objIter = list.iterator();
			;
			String str = null;
			str = newheader + "\n";
			String[] strarr = newheader.split("\\|");
			List<String> strlist = Arrays.asList(strarr);

			while (objIter.hasNext()) {
				// Employee e = new Employee();
				Object[] tuple = (Object[]) objIter.next();
				// str=str+10+"|";
				
				for (int i = 0; i < tuple.length; i++) {

					String datatype = strlist.get(i);
					//for (String str1 : strlist) {
						switch (metadataMap.get(datatype.trim())) {
						case "INT":
							str = str + (Integer) tuple[i] + "|";
							break;
						case "VARCHAR":
							str = str + (String) tuple[i] + "|";
							break;
						case "date":
							str = str + (String) tuple[i] + "|";
							break;

						//}

					}

				}
				str = str.substring(0, str.length() - 1);

				liststr.add(str);
				str = "";
			}
			saveDataToFile(liststr, tableName);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// }/*else if(tableName.equalsIgnoreCase("Department")) {
		// list = myEntityRepositoryCustom.findRecordWithQuery(query);
		// saveDataToFile(list,tableName);
		// }*/

		// List<Employee> listEmployee = (List<Employee>) (Object)
		// myEntityRepositoryCustom.findRecordWithQuery(query);

		// List<Employee> listemp = new ArrayList<Employee>();
		// for(Object[] e: listEmployee) {
		// Employee mobj = mobj.setId(e[0]);
		// listemp.add(mobj);
		// }
		// JSONArray array = new JSONArray();
		/*
		 * for (Employee gi : listEmployee) { JSONObject obj = new JSONObject();
		 * obj.put("id", gi.getId()); obj.put("first_name", gi.getFirstName());
		 * obj.put("last_name", gi.getLastName()); obj.put("emailId", gi.getEmailId());
		 * array.add(obj); }
		 * 
		 */ /*
			 * for(Object ob:listEmployee) { JSONObject jsonObj = new JSONObject();
			 * 
			 * jsArray.add(0, ob); }
			 */
		// }

		// employeeService.saveEmployeeIgniteRepository(listEmployee);
		return liststr;

		// return
		// employeeService.findRecordWithQuery(parameter.getAttribute(),parameter.getTable(),parameter.getFilter());
	}

	private Map<String, String> getMetaData(String newheader, String table) {

		Map<String, String> mapColumnNameType = new HashMap<String, String>();
		try (Connection conn = DriverManager.getConnection(url, username, password)) {

			DatabaseMetaData meta = conn.getMetaData();

			String catalog = null, schemaPattern = null, tableNamePattern = null;
			String[] types = { "TABLE" };

			ResultSet rsTables = meta.getTables(catalog, schemaPattern, tableNamePattern, types);
			String[] strarr = newheader.split("\\|");
			List<String> strlist = Arrays.asList(strarr);
			strlist.replaceAll(String::trim);

			while (rsTables.next()) {
				if (rsTables.getString(3).contentEquals(table)) {
					String tableName = rsTables.getString(3);
					System.out.println("\n=== TABLE: " + tableName);

					String columnNamePattern = null;
					ResultSet rsColumns = meta.getColumns(catalog, schemaPattern, tableName, columnNamePattern);

					ResultSet rsPK = meta.getPrimaryKeys(catalog, schemaPattern, tableName);

					while (rsColumns.next()) {
						String columnName = rsColumns.getString("COLUMN_NAME");
						if (strlist.contains(columnName)) {
							String columnType = rsColumns.getString("TYPE_NAME");
							int columnSize = rsColumns.getInt("COLUMN_SIZE");
							System.out.println("\t" + columnName + " - " + columnType + "(" + columnSize + ")");
							mapColumnNameType.put(columnName.trim(), columnType.trim());
							// medataStr=medataStr+columnName+"|"+columnType+",";
						}
					}

					while (rsPK.next()) {
						String primaryKeyColumn = rsPK.getString("COLUMN_NAME");
						System.out.println("\tPrimary Key Column: " + primaryKeyColumn);
					}

				}

			}

		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}

		return mapColumnNameType;
	}

	public void saveDataToFile(List<?> list, String filename) {
		String str1 = "";
		for (int i = 0; i < list.size(); i++) {
			str1 = str1 + list.get(i).toString() + "\n";

		}
		System.out.println(str1);
		byte data[] = str1.getBytes();
		Path p = Paths.get("C://work/" + filename + ".txt");

		try (OutputStream out = new BufferedOutputStream(Files.newOutputStream(p))) {
			out.write(data, 0, data.length);
		} catch (IOException x) {
			System.err.println(x);
		}
	}

	/*
	 * @RequestMapping(value = "/employee/query", method = RequestMethod.GET) String
	 * getEmployeewithQuery(@RequestParam Integer id) throws
	 * ResourceNotFoundException{ Parameter parameter = getParameter(id); String
	 * query=""; //String query =
	 * "select "+parameter.getAttribute()+" from "+parameter.getTable()+" where "
	 * +parameter.getFilter(); if(parameter.getFilter().equals("null")) { query =
	 * "select "+parameter.getAttribute()+" from "+parameter.getTable();
	 * 
	 * }else { query =
	 * "select "+parameter.getAttribute()+" from "+parameter.getTable()+" where "
	 * +parameter.getFilter();
	 * 
	 * }
	 * 
	 * System.out.println("query::"+query); return
	 * myEntityRepositoryCustom.findRecordWithQuery(query).toString(); //return
	 * employeeService.findRecordWithQuery(parameter.getAttribute(),parameter.
	 * getTable(),parameter.getFilter()); }
	 * 
	 * 
	 * @RequestMapping(value = "/parameter", method = RequestMethod.GET) Parameter
	 * getParameter(@RequestParam Integer id) throws ResourceNotFoundException{
	 * Parameter parameter = parameterRepository.findById(id) .orElseThrow(() -> new
	 * ResourceNotFoundException("Parameter not found for this id :: " + id));
	 * 
	 * //parameterService.saveParameterIgniteRepository(parameter);
	 * 
	 * return parameter; }
	 */

	/*
	 * @PutMapping("/employees/{id}") public ResponseEntity<Employee>
	 * updateEmployee(@PathVariable(value = "id") Long employeeId,
	 * 
	 * @Valid @RequestBody Employee employeeDetails) throws
	 * ResourceNotFoundException { Employee employee =
	 * employeeRepository.findById(employeeId) .orElseThrow(() -> new
	 * ResourceNotFoundException("Employee not found for this id :: " +
	 * employeeId));
	 * 
	 * employee.setEmailId(employeeDetails.getEmailId());
	 * employee.setLastName(employeeDetails.getLastName());
	 * employee.setFirstName(employeeDetails.getFirstName()); final Employee
	 * updatedEmployee = employeeRepository.save(employee); return
	 * ResponseEntity.ok(updatedEmployee); }
	 * 
	 * @DeleteMapping("/employees/{id}") public Map<String, Boolean>
	 * deleteEmployee(@PathVariable(value = "id") Long employeeId) throws
	 * ResourceNotFoundException { Employee employee =
	 * employeeRepository.findById(employeeId) .orElseThrow(() -> new
	 * ResourceNotFoundException("Employee not found for this id :: " +
	 * employeeId));
	 * 
	 * employeeRepository.delete(employee); Map<String, Boolean> response = new
	 * HashMap<>(); response.put("deleted", Boolean.TRUE); return response; }
	 */
}
