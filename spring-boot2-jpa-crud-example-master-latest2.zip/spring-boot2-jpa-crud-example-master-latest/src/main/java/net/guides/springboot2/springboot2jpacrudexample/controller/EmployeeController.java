package net.guides.springboot2.springboot2jpacrudexample.controller;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import net.guides.springboot2.springboot2jpacrudexample.exception.ResourceNotFoundException;
import net.guides.springboot2.springboot2jpacrudexample.model.Department;
import net.guides.springboot2.springboot2jpacrudexample.model.Employee;
import net.guides.springboot2.springboot2jpacrudexample.repository.EmployeeRepository;
import net.guides.springboot2.springboot2jpacrudexample.service.EmployeeService;
import net.guides.springboot2.springboot2jpacrudexample.service.MyEntityRepositoryCustom;
import net.guides.springboot2.springboot2jpacrudexample.service.ParameterRepository;
import net.guides.springboot2.springboot2jpacrudexample.service.ParameterService;


@RestController
@RequestMapping("/api/v1")
public class EmployeeController {
	@Autowired
	private EmployeeRepository employeeRepository;
	
   @Autowired
    private ParameterRepository parameterRepository;
   
   @Autowired
   private ParameterService parameterService;
   @Autowired
   private EmployeeService employeeService;
    @Autowired
    private MyEntityRepositoryCustom myEntityRepositoryCustom;

	/*@GetMapping("/employees")
	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();
	}

	@GetMapping("/employees/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable(value = "id") Long employeeId)
			throws ResourceNotFoundException {
		Employee employee = employeeRepository.findById(employeeId)
				.orElseThrow(() -> new ResourceNotFoundException("parameter not found for this id :: " + employeeId));
		return ResponseEntity.ok().body(employee);
	}

	@PostMapping("/employees")
	public Employee createEmployee(@Valid @RequestBody Employee employee) {
		return employeeRepository.save(employee);
	}*/
	
	@RequestMapping(value = "/table/filter", method = RequestMethod.GET)
	 List<?> getEmployeewithQuery(@RequestParam Map<String,String> params) throws ResourceNotFoundException, ClassNotFoundException{
  //  Parameter parameter = getParameter(table);
		String tableName = params.get("table");
		String query="select * from "+tableName+" where ";
		params.remove("table");
		for(Map.Entry<String,String> entry: params.entrySet()) {
			  query=query+entry.getKey()+"='"+entry.getValue()+"' and ";
		}
		
		query= query.substring(0,query.lastIndexOf("and")-1);
   
   // String filter = parameter.getFilter();
   // String filterCondtion= filter+"='"+param+"'";
    
		/*
		 * //String query =
		 * "select "+parameter.getAttribute()+" from "+parameter.getTable()+" where "
		 * +parameter.getFilter(); if(parameter.getFilter().equals("null")) { query =
		 * "select "+parameter.getAttribute()+" from "+parameter.getTable();
		 * 
		 * }else { query =
		 * "select "+parameter.getAttribute()+" from "+parameter.getTable()+" where "
		 * +filterCondtion;
		 * 
		 * }
		 */
   
    System.out.println("query::"+query);
    
    	List<?> list = new ArrayList<>();
   
    	JSONArray jsArray = new JSONArray();
    	if(tableName.equalsIgnoreCase("Employee")) {
   	    	 list = (List<Employee>) (Object) myEntityRepositoryCustom.findRecordWithQuery(query);
   	    	saveDataToFile(list,tableName);
   	    	
    
    	}else if(tableName.equalsIgnoreCase("Department")) {
    		 list = (List<Department>) (Object) myEntityRepositoryCustom.findRecordWithQuery(query);
    		 saveDataToFile(list,tableName);
    	}
    	
    	//List<Employee> listEmployee = (List<Employee>) (Object) myEntityRepositoryCustom.findRecordWithQuery(query);
    	
    	//List<Employee> listemp = new ArrayList<Employee>();
    //	for(Object[] e: listEmployee) {
    		//Employee mobj = mobj.setId(e[0]);
    		//listemp.add(mobj);
    	//}
    //	JSONArray array = new JSONArray();
		/*
		 * for (Employee gi : listEmployee) { JSONObject obj = new JSONObject();
		 * obj.put("id", gi.getId()); obj.put("first_name", gi.getFirstName());
		 * obj.put("last_name", gi.getLastName()); obj.put("emailId", gi.getEmailId());
		 * array.add(obj); }
		 * 
		 */	/*
		 * for(Object ob:listEmployee) { JSONObject jsonObj = new JSONObject();
		 * 
		 * jsArray.add(0, ob); }
		 */
   // }
    
   // employeeService.saveEmployeeIgniteRepository(listEmployee);
    return list;
    
    
    //return  employeeService.findRecordWithQuery(parameter.getAttribute(),parameter.getTable(),parameter.getFilter());
    }
	
	public void saveDataToFile(List list,String filename) {
		String str1="";
		for (int i = 0; i < list.size(); i++) {
			String str = list.get(i).toString().concat("|");
			
			str1 =str1+ str.substring(1, str.length() - 1) + "\n";
			
			
		}
		System.out.println(str1);
			byte data[] = str1.getBytes();
			Path p = Paths.get("C://work/"+filename+".txt");

			try (OutputStream out = new BufferedOutputStream(Files.newOutputStream(p))) {
				out.write(data, 0, data.length);
			} catch (IOException x) {
				System.err.println(x);
			}
	}
	
	
	 
    /*@RequestMapping(value = "/employee/query", method = RequestMethod.GET)
   String getEmployeewithQuery(@RequestParam Integer id) throws ResourceNotFoundException{
    	Parameter parameter = getParameter(id);
    	String query="";
    	//String query = "select "+parameter.getAttribute()+" from "+parameter.getTable()+" where "+parameter.getFilter();
        if(parameter.getFilter().equals("null")) {
        	 query = "select "+parameter.getAttribute()+" from "+parameter.getTable();
            
        }else {
        	 query = "select "+parameter.getAttribute()+" from "+parameter.getTable()+" where "+parameter.getFilter();
            
        }
    	 
    	System.out.println("query::"+query);
    	return myEntityRepositoryCustom.findRecordWithQuery(query).toString();
    	//return  employeeService.findRecordWithQuery(parameter.getAttribute(),parameter.getTable(),parameter.getFilter());
    }
    
    
    @RequestMapping(value = "/parameter", method = RequestMethod.GET)
    Parameter getParameter(@RequestParam Integer id) throws ResourceNotFoundException{
    	Parameter parameter = parameterRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Parameter not found for this id :: " + id));

    	//parameterService.saveParameterIgniteRepository(parameter);
    	
        return  parameter;
    }*/

    
   
	/*@PutMapping("/employees/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable(value = "id") Long employeeId,
			@Valid @RequestBody Employee employeeDetails) throws ResourceNotFoundException {
		Employee employee = employeeRepository.findById(employeeId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: " + employeeId));

		employee.setEmailId(employeeDetails.getEmailId());
		employee.setLastName(employeeDetails.getLastName());
		employee.setFirstName(employeeDetails.getFirstName());
		final Employee updatedEmployee = employeeRepository.save(employee);
		return ResponseEntity.ok(updatedEmployee);
	}

	@DeleteMapping("/employees/{id}")
	public Map<String, Boolean> deleteEmployee(@PathVariable(value = "id") Long employeeId)
			throws ResourceNotFoundException {
		Employee employee = employeeRepository.findById(employeeId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: " + employeeId));

		employeeRepository.delete(employee);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}*/
}
