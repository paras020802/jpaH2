package net.guides.springboot2.springboot2jpacrudexample.service;

import java.util.List;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.Ignition;
import org.springframework.stereotype.Component;

import net.guides.springboot2.springboot2jpacrudexample.model.Employee;
import net.guides.springboot2.springboot2jpacrudexample.model.Parameter;

@Component
public class EmployeeServiceImpl implements EmployeeService {

	public void saveEmployeeIgniteRepository(List<Employee> employees) {
		
	try {
		
			Ignition.setClientMode(true);
			Ignite ignite = Ignition.start("examples/config/example-ignite.xml");
		

	        // get or create cache
	        IgniteCache<Integer, Employee> cache =  ignite.getOrCreateCache("employeesCache");
	      int count=0;  
	      for(Employee employee:employees) {
	    	  cache.put(new Integer(count), employee);
	    	  count++;
	      }


        System.out.println("Enter crtl-x to quite the application!!!");
	}catch(Exception e) {
		e.printStackTrace();
	}
		
	}

}
