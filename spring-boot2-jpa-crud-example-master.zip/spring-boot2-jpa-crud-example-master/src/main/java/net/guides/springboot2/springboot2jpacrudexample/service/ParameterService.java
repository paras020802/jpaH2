package net.guides.springboot2.springboot2jpacrudexample.service;

import org.springframework.data.jpa.repository.JpaRepository;

import net.guides.springboot2.springboot2jpacrudexample.model.Parameter;

public interface ParameterService extends JpaRepository<Parameter, Integer>{
}
