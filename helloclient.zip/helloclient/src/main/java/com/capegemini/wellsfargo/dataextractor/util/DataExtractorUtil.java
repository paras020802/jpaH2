package com.capegemini.wellsfargo.dataextractor.util;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.capegemini.wellsfargo.dataextractor.model.Metadata;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DataExtractorUtil {
	
	public static String getTableNameFromQuery(String query) {
		String tableName = null;
		if (query.contains("where")) {
			tableName = query.substring(query.indexOf("from") + 4, query.indexOf("where") - 1).trim();
		} else {
			tableName = query.substring(query.indexOf("from") + 4, query.length()).trim();
		}
		return tableName;

	}

	public static List<String> getColumnHeaderList(String header,String delimited) {
		
		String[] headerArr = header.split(delimited);
		List<String> headerList = Arrays.asList(headerArr);
		headerList.replaceAll(String::trim);
		return headerList;
	}
	
	
	
	
	public static String getColumnHeaderString(String query) {
		String header = query.substring(6, query.indexOf("from") - 1);
		System.out.println("newheader::" + header.trim());
		return header;
	}
	
	public static Map<String,String> getMetadataMapfromJson(String response) throws JsonParseException, JsonMappingException, IOException{
		Map<String, String> metadataMap = new LinkedHashMap<String, String>();
		ObjectMapper mapper = new ObjectMapper();
		List<Metadata> metadataList = Arrays.asList(mapper.readValue(response, Metadata[].class));
		
		for(Metadata metadata:metadataList) {
			metadataMap.put(metadata.getColumnName(),metadata.getColumnType());
		}
		return metadataMap;

	}
	public static void saveDataToFile(List<?> list, String filename,int records) {
		String str1 = "";
		for (int i = 0; i < list.size(); i++) {
			str1 = str1 + list.get(i).toString() + "\n";

		}
		System.out.println(str1);
		byte data[] = str1.getBytes();
		String createDate = DataExtractorUtil.getFileCreateDateTime();
		String triggerfileHeader="tableName|"+"No Of Records|"+"Date & time";
		String triggerfiledata= filename +"|"+records+"|"+createDate;
		String triggerdata= triggerfileHeader+"\n"+triggerfiledata;
		Path filePath1 = Paths.get("C://work/" + filename + ".txt");
		Path triggerFilePath = Paths.get("C://work/" + filename+"_trigger" + ".txt");
		byte triggerdatabyte[] = triggerdata.getBytes();
		try (OutputStream out = new BufferedOutputStream(Files.newOutputStream(filePath1))) {
			out.write(data, 0, data.length);
		} catch (IOException x) {
			System.err.println(x);
		}
		try (OutputStream out1 = new BufferedOutputStream(Files.newOutputStream(triggerFilePath))) {
			out1.write(triggerdatabyte);
		} catch (IOException x) {
			System.err.println(x);
		}
	}

	public static String getFileCreateDateTime() {
		DateFormat dateFormat = new SimpleDateFormat("MM-dd-YYYY HH:mm:ss");
		Date date = new Date();
		System.out.println(dateFormat.format(date));
		return dateFormat.format(date);
	}

	public static boolean checkQuerySyntaxValid(String query) {
		if(query.contains("select") && query.contains("from")) {
			String body = query.substring(6,query.lastIndexOf("from")-1);
			if(body!=null && (body.trim().equals("*")||body.trim().length()>0)) {
				return true;
			}
		}
		
		return false;
	}
}
