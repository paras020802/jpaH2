package com.capegemini.wellsfargo.dataextractor.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capegemini.wellsfargo.dataextractor.model.Audit;

@Repository
public interface AuditRepositoryImpl extends JpaRepository<Audit, Long>{

}
