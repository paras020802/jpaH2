package com.capegemini.wellsfargo.dataextractor.repository;

import java.util.List;

import javax.persistence.PersistenceException;

public interface DataExtractorRepository {
	  <T> List<T> findRecordWithQuery(String query) throws PersistenceException;
}
