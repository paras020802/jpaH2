package com.capegemini.wellsfargo.dataextractor.service;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.exception.SQLGrammarException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capegemini.wellsfargo.dataextractor.model.Audit;
import com.capegemini.wellsfargo.dataextractor.repository.AuditRepositoryImpl;
import com.capegemini.wellsfargo.dataextractor.repository.DataExtractorRepository;
import com.capegemini.wellsfargo.dataextractor.util.DataExtractorUtil;

@Component
public class DataExtractorServiceImpl implements DataExtractorService{
	
	@Autowired
	private DataExtractorRepository dataExtractorRepository;

	@Autowired
	private AuditRepositoryImpl auditRepository;
	
	public <T> List<T> getDataExtractor(String query) throws SQLException {
		List list = new ArrayList();
		try {
		 list =  dataExtractorRepository.findRecordWithQuery(query);
		}catch(SQLGrammarException excp) {
			throw new SQLException();
		}
	return list;
	}



	@Override
	public JSONArray getDataExtractorResult(List<Object> list, Map<String, String> metadataMap,String query) {
		JSONArray jsonarray= new JSONArray();
		try {
			
			String tableName = DataExtractorUtil.getTableNameFromQuery(query);
			String header="";
			if(!query.contains("*")) {
				 header = DataExtractorUtil.getColumnHeaderString(query);
			}else {
				for(Map.Entry<String,String> entry: metadataMap.entrySet()) {
					header=header+entry.getKey()+"|";
				}
				header=header.substring(0,header.length()-1).trim();
			}
			
			System.out.println("header::"+header);
			List<String> headerList = new ArrayList<String>();
			if(query.contains("*")) {
				 headerList = DataExtractorUtil.getColumnHeaderList(header.toUpperCase(),"\\|");
			}else {
				headerList = DataExtractorUtil.getColumnHeaderList(header.toUpperCase(),"\\,");
			}
			
			//Iterator<Object> objIter = list.iterator();
			String str = null;
			str = header + "\n";
			List<String> liststr = new ArrayList<String>(list.size());
			
			for(int k=0;k<list.size();k++) {
				Object obj=list.get(k);
				JSONObject jo= new JSONObject();
				if(obj instanceof String) {
					System.out.println("object::"+obj);
					Object tuple = (Object) obj;
					String datatype = headerList.get(0);
					
						switch (metadataMap.get(datatype.trim())) {
						case "INT":
							str = str + (Integer) tuple + "|";
							jo.put(datatype, (Integer) tuple);
							break;
						case "VARCHAR":
							str = str + (String) tuple + "|";
							jo.put(datatype, (String) tuple);
							break;
						case "date":
							str = str + (Timestamp) tuple + "|";
							jo.put(datatype, (Timestamp) tuple);
							break;

						//}

					}
				}else {
					Object[] tuple = (Object[]) obj;
					for (int i = 0; i < tuple.length; i++) {

						String datatype = headerList.get(i);
						//for (String str1 : strlist) {
							switch (metadataMap.get(datatype.trim())) {
							case "INT":
								str = str + (Integer) tuple[i] + "|";
								jo.put(datatype, (Integer) tuple[i]);
								break;
							case "VARCHAR":
								str = str + (String) tuple[i] + "|";
								jo.put(datatype, (String) tuple[i]);
								break;
							case "DATE":
								str = str + (Timestamp) tuple[i] + "|";
								jo.put(datatype, (Timestamp) tuple[i]);
								break;

							//}

						}

					}
				}
				jsonarray.add(jo);
			}
			
				
				str = str.substring(0, str.length() - 1);

				liststr.add(str.trim());
				str = "";
			
			DataExtractorUtil.saveDataToFile(liststr, tableName,jsonarray.size());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return jsonarray;
		
	}



	@Override
	public Audit saveAuditMetadata(Audit audit) {
		return auditRepository.save(audit);
	}
	
	
	
}

