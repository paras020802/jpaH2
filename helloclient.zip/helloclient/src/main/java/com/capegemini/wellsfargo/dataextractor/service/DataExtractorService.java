package com.capegemini.wellsfargo.dataextractor.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;

import com.capegemini.wellsfargo.dataextractor.model.Audit;

public interface DataExtractorService {

	public  <T> List<T> getDataExtractor(String query) throws SQLException;

	public JSONArray getDataExtractorResult(List<Object> list, Map<String, String> metadataMap,String query);

	public Audit saveAuditMetadata(Audit audit);

}
