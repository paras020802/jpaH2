package com.capegemini.wellsfargo.metadataextractor.controller;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/rest/metadata")
public class MetadataServiceController {

	@Value("${spring.datasource.url}")
	private String url;

	@Value("${spring.datasource.username}")
	private String username;

	@Value("${spring.datasource.password}")
	private String password;

	@GetMapping
	public String hello() {

		return "hello server I am testing";
	}

	@RequestMapping(value = "/service", method = RequestMethod.GET)
	private String getMetaData(@RequestParam(required = false) String header, @RequestParam String table) {
		System.out.println("header::" + header);
		System.out.println("table::" + table);
		List<String> headerList = new ArrayList<String>();
		if (header != null) {
			String[] headerArr = header.split("\\,");
			headerList = Arrays.asList(headerArr);
			headerList.replaceAll(String::trim);
			headerList =headerList.stream().map(s->s.toUpperCase()).collect(Collectors.toList());
		}

		Map<String, String> mapColumnNameType = new LinkedHashMap<String, String>();
		
		try (Connection conn = DriverManager.getConnection(url, username, password)) {

			DatabaseMetaData meta = conn.getMetaData();

			String catalog = null, schemaPattern = null, tableNamePattern = null;
			String[] types = { "TABLE" };

			ResultSet rsTables = meta.getTables(catalog, schemaPattern, tableNamePattern, types);

			while (rsTables.next()) {
				if (rsTables.getString(3).contentEquals(table)) {
					String tableName = rsTables.getString(3);
					System.out.println("\n=== TABLE: " + tableName);

					String columnNamePattern = null;
					ResultSet rsColumns = meta.getColumns(catalog, schemaPattern, tableName, columnNamePattern);

					ResultSet rsPK = meta.getPrimaryKeys(catalog, schemaPattern, tableName);

					while (rsColumns.next()) {
						String columnName = rsColumns.getString("COLUMN_NAME").toUpperCase();
						String columnType = rsColumns.getString("TYPE_NAME").toUpperCase();
						int columnSize = rsColumns.getInt("COLUMN_SIZE");
						System.out.println("\t" + columnName + " - " + columnType + "(" + columnSize + ")");
						mapColumnNameType.put(columnName.trim(), columnType.trim());
						
					}
					
					
					if (headerList.size() != 0) {
						//for(String mapElement:headerList) {
							
							mapColumnNameType= mapColumnNameType.entrySet().stream().filter(p-> header.toUpperCase().contains(p.getKey()))
								
									.collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue));
							
						/*
						 * Iterator it = mapColumnNameType.entrySet().iterator(); while(it.hasNext()) {
						 * Map.Entry item= (Map.Entry)it.next(); if(!item.getKey().equals(mapElement)) {
						 * it.remove(); }
						 * 
						 * }
						 */
							
							/*
							 * for(Map.Entry<String,String> entry: mapColumnNameType.entrySet()) {
							 * if(!entry.getKey().equals(mapElement)) {
							 * mapColumnNameType.remove(entry.getKey()); } }
							 */

						//}
					}

					while (rsPK.next()) {
						String primaryKeyColumn = rsPK.getString("COLUMN_NAME");
						System.out.println("\tPrimary Key Column: " + primaryKeyColumn);
					}

				}

			}
			System.out.println("map values::" + mapColumnNameType.toString());

		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}

		return mapColumnNameType.toString();
	}

}
