package com.capegemini.wellsfargo.dataextractor.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;

@Component
public class DataExtractorRepositoryImpl implements DataExtractorRepository {

	@PersistenceContext
    private EntityManager em;

 

	@Override
	public <T> List<T> findRecordWithQuery(String query) {
		   List list = em.createNativeQuery(query).getResultList();
	        return list;
	}
}
