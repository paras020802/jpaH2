package com.capegemini.wellsfargo.dataextractor.repository;

import java.util.List;

public interface DataExtractorRepository {
	  <T> List<T> findRecordWithQuery(String query);
}
