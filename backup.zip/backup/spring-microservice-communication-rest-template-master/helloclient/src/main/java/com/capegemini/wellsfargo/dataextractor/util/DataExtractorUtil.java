package com.capegemini.wellsfargo.dataextractor.util;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class DataExtractorUtil {
	
	public static String getTableNameFromQuery(String query) {
		String tableName = null;
		if (query.contains("where")) {
			tableName = query.substring(query.indexOf("from") + 4, query.indexOf("where") - 1).trim();
		} else {
			tableName = query.substring(query.indexOf("from") + 4, query.length()).trim();
		}
		return tableName;

	}

	public static List<String> getColumnHeaderList(String header) {
		
		String[] headerArr = header.split("\\|");
		List<String> headerList = Arrays.asList(headerArr);
		headerList.replaceAll(String::trim);
		return headerList;
	}
	
	
	public static String getColumnHeaderString(String query) {
		String header = query.substring(6, query.indexOf("from") - 1);
		String newheader = header.replace(",", "|");
		System.out.println("newheader::" + newheader.trim());
		return newheader;
	}
	
	public static Map<String,String> getMetadataMap(String response){
		Map<String, String> metadataMap = new LinkedHashMap<String, String>();
		
		String result= response.substring(1,response.length()-1);
		String metadataArr[]= result.split("\\,");
		for(String metadata:metadataArr) {
			String metainfo[] = metadata.split("\\=");
			String columnName = metainfo[0].trim();
			String columnType = metainfo[1].trim();
			metadataMap.put(columnName,columnType);
		}
		return metadataMap;

	}
	public static void saveDataToFile(List<?> list, String filename) {
		String str1 = "";
		for (int i = 0; i < list.size(); i++) {
			str1 = str1 + list.get(i).toString() + "\n";

		}
		System.out.println(str1);
		byte data[] = str1.getBytes();
		Path p = Paths.get("C://work/" + filename + ".txt");

		try (OutputStream out = new BufferedOutputStream(Files.newOutputStream(p))) {
			out.write(data, 0, data.length);
		} catch (IOException x) {
			System.err.println(x);
		}
	}
}
