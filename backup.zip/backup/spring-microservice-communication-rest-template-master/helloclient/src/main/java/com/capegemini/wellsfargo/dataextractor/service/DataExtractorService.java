package com.capegemini.wellsfargo.dataextractor.service;

import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;

public interface DataExtractorService {

	public  <T> List<T> getDataExtractor(String query);

	public JSONArray getDataExtractorResult(List<Object> list, Map<String, String> metadataMap,String query);

}
