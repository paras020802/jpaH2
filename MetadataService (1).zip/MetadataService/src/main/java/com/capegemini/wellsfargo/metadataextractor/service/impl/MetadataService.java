package com.capegemini.wellsfargo.metadataextractor.service.impl;

import java.util.List;

import org.json.simple.JSONArray;

public interface MetadataService {

	List<Object> extractTablesMetadata(String query);

	JSONArray getMetadataResult(List<String> headerList, List<Object> list);

}
