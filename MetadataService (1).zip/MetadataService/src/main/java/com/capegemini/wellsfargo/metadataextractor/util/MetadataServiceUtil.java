package com.capegemini.wellsfargo.metadataextractor.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MetadataServiceUtil {
	
	
	public static List<String> getColumnHeaderList(String header) {
		List<String> headerList = new ArrayList<String>();
		if (header != null) {
				String[] headerArr = header.split("\\,");
				headerList = Arrays.asList(headerArr);
				headerList.replaceAll(String::trim);
				headerList = headerList.stream().map(s -> s.toUpperCase()).collect(Collectors.toList());
			
		}
		return headerList;

	}
	
	
	
}
