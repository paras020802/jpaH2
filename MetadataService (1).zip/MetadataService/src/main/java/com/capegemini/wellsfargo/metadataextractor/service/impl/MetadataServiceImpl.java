package com.capegemini.wellsfargo.metadataextractor.service.impl;

import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capegemini.wellsfargo.metadataextractor.repository.MetadataServiceRepository;

@Service
public class MetadataServiceImpl implements MetadataService {

	@Autowired
	MetadataServiceRepository metadataServiceRepository;

	public List<Object> extractTablesMetadata(String query) {

		return metadataServiceRepository.findRecordWithQuery(query);
	}

	@Override
	public JSONArray getMetadataResult(List<String> headerList, List<Object> list) {
		JSONArray jsonarray = new JSONArray();
		try {
			for (int k = 0; k < list.size(); k++) {
				Object obj = list.get(k);
				JSONObject jo = new JSONObject();

				Object[] tuple = (Object[]) obj;
				String column_name = tuple[0].toString().toUpperCase();
				String datatype = tuple[1].toString();
				String column_type = datatype.substring(0, datatype.indexOf("(")).toUpperCase();
				String column_size = datatype.substring(datatype.indexOf("(") + 1, datatype.indexOf(")"));
				if (headerList != null && headerList.size() > 0) {
					if (headerList.contains(column_name)) {
						jo.put("columnName", column_name);
						jo.put("columnType", column_type);
						jo.put("columnSize", column_size);
						jsonarray.add(jo);
					}
				} else {
					jo.put("columnName", column_name);
					jo.put("columnType", column_type);
					jo.put("columnSize", column_size);
					jsonarray.add(jo);
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return jsonarray;
	}

}
