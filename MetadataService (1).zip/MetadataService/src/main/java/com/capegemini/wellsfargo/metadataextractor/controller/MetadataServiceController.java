package com.capegemini.wellsfargo.metadataextractor.controller;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capegemini.wellsfargo.metadataextractor.service.impl.MetadataService;
import com.capegemini.wellsfargo.metadataextractor.util.MetadataServiceUtil;

@RestController
@RequestMapping(value = "/rest/metadata")
public class MetadataServiceController {

	@Autowired
	MetadataService metadataService;

	@RequestMapping(value = "/service", method = RequestMethod.GET)
	private ResponseEntity<String> getMetaData(@RequestParam(required = false) String header,
			@RequestParam String table, @RequestParam(required = false) String param) {

		System.out.println("header::" + header);
		System.out.println("table::" + table);
		System.out.println("param::" + param);
		
		List<String> headerList = MetadataServiceUtil.getColumnHeaderList(header);
		
		String query = "select column_name,column_type from columns where table_name='" + table + "'";
		System.out.println("query::" + query);

		List<Object> list = new ArrayList<>();
		list = metadataService.extractTablesMetadata(query);
		JSONArray jsonArr = metadataService.getMetadataResult(headerList,list);

		
		if (param != null) {
			// return ResponseEntity.ok().body(mapColumnNameType.toString()); // return
			// mapColumnNameType.toString();
		} else {
			return ResponseEntity.ok().body(jsonArr.toString()); // return
			
		}
		return ResponseEntity.ok().body(jsonArr.toString());

	}

}
